# 🛠️ Guide d'Installation - Java et Maven

## ❌ Problème
```
java: command not found
mvn: command not found
```

L'application ne peut pas démarrer car **Java** et **Maven** ne sont pas installés sur votre système.

---

## ✅ Solutions

### 🪟 **WINDOWS - Option 1 : Chocolatey (Recommandé)**

#### 1. Installer Chocolatey (si pas encore installé)

Ouvrir **PowerShell en mode Administrateur** et exécuter :

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```

#### 2. Installer Java 17

```powershell
choco install openjdk17 -y
```

#### 3. Installer Maven

```powershell
choco install maven -y
```

#### 4. Vérifier l'installation

Fermer et rouvrir le terminal, puis :

```bash
java -version
mvn -version
```

#### 5. Lancer l'application

```bash
cd C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee
mvn spring-boot:run
```

---

### 🪟 **WINDOWS - Option 2 : Installation Manuelle**

#### 1. Télécharger Java 17

1. Aller sur : https://adoptium.net/
2. Télécharger **Eclipse Temurin 17 (LTS)** pour Windows
3. Installer avec les options par défaut
4. ✅ **Cocher "Set JAVA_HOME variable"** pendant l'installation

#### 2. Télécharger Maven

1. Aller sur : https://maven.apache.org/download.cgi
2. Télécharger **Binary zip archive** (ex: apache-maven-3.9.6-bin.zip)
3. Extraire dans `C:\Program Files\Apache\Maven`

#### 3. Configurer les variables d'environnement

**Ajouter Maven au PATH :**

1. Rechercher "Variables d'environnement" dans Windows
2. Cliquer sur "Variables d'environnement"
3. Dans "Variables système", trouver "Path", cliquer "Modifier"
4. Cliquer "Nouveau" et ajouter : `C:\Program Files\Apache\Maven\bin`
5. Cliquer OK sur toutes les fenêtres

**Vérifier JAVA_HOME :**

1. Dans "Variables système", vérifier qu'il existe "JAVA_HOME"
2. Si non, créer avec : `C:\Program Files\Eclipse Adoptium\jdk-17.x.x-hotspot`

#### 4. Vérifier l'installation

**Fermer tous les terminaux**, ouvrir un **nouveau terminal** :

```bash
java -version
mvn -version
```

#### 5. Lancer l'application

```bash
cd C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee
mvn clean install
mvn spring-boot:run
```

---

### 🪟 **WINDOWS - Option 3 : IntelliJ IDEA (Plus Simple)**

Si vous avez **IntelliJ IDEA** :

#### 1. Télécharger IntelliJ IDEA Community (Gratuit)
- https://www.jetbrains.com/idea/download/

#### 2. Ouvrir le projet
1. Ouvrir IntelliJ IDEA
2. File → Open
3. Sélectionner le dossier `kind-chatterjee`
4. IntelliJ détectera automatiquement le projet Maven

#### 3. IntelliJ installera Java et Maven automatiquement
- Il téléchargera et configurera tout automatiquement

#### 4. Lancer l'application
1. Ouvrir `BookManagementApplication.java`
2. Cliquer sur la flèche verte ▶️ à gauche de `public static void main`
3. Sélectionner "Run 'BookManagementApplication'"

✅ **L'application démarre automatiquement !**

---

### 🪟 **WINDOWS - Option 4 : Eclipse**

Si vous avez **Eclipse** :

#### 1. Télécharger Eclipse IDE for Java Developers
- https://www.eclipse.org/downloads/

#### 2. Importer le projet
1. File → Import → Maven → Existing Maven Projects
2. Sélectionner le dossier `kind-chatterjee`
3. Finish

#### 3. Lancer l'application
1. Clic droit sur `BookManagementApplication.java`
2. Run As → Java Application

---

### 🪟 **WINDOWS - Option 5 : VS Code**

Si vous avez **Visual Studio Code** :

#### 1. Installer les extensions
- Extension Pack for Java
- Spring Boot Extension Pack

#### 2. Ouvrir le projet
```bash
code C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee
```

#### 3. VS Code installera Java automatiquement
- Il détectera le projet et proposera d'installer le JDK

#### 4. Lancer l'application
1. Ouvrir `BookManagementApplication.java`
2. Clic droit → Run Java
3. Ou cliquer sur "Run" au-dessus de la méthode `main`

---

## 🚀 Méthode Rapide Recommandée

### **Pour les débutants : IntelliJ IDEA**

1. **Télécharger IntelliJ IDEA Community** (gratuit)
   - https://www.jetbrains.com/idea/download/

2. **Installer et ouvrir**

3. **File → Open → Sélectionner le dossier `kind-chatterjee`**

4. **Attendre** qu'IntelliJ configure tout automatiquement (5-10 minutes)

5. **Ouvrir `BookManagementApplication.java`**

6. **Cliquer sur ▶️ Run**

✅ **C'est tout ! L'application démarre.**

---

## 🔍 Vérification Après Installation

Une fois Java et Maven installés, vérifier :

```bash
# Version Java (doit être 17 ou supérieur)
java -version

# Résultat attendu :
# openjdk version "17.0.x"

# Version Maven (doit être 3.8 ou supérieur)
mvn -version

# Résultat attendu :
# Apache Maven 3.9.x
```

---

## 🎯 Lancement de l'Application

### Méthode 1 : Ligne de commande

```bash
cd C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee
mvn clean install
mvn spring-boot:run
```

### Méthode 2 : Via IDE (IntelliJ/Eclipse/VS Code)

Ouvrir le projet dans l'IDE et cliquer sur "Run" ▶️

---

## ✅ Application Démarrée

Quand vous verrez :

```
========================================
Application de Gestion des Livres démarrée !
Interface Web : http://localhost:8080/books
API REST : http://localhost:8080/api/books
Swagger UI : http://localhost:8080/swagger-ui.html
Console H2 : http://localhost:8080/h2-console
========================================
```

✅ **Ouvrir votre navigateur** et aller sur :
- http://localhost:8080/books

---

## ❓ Problèmes Courants

### Port 8080 déjà utilisé

**Erreur :** `Port 8080 is already in use`

**Solution :** Modifier le port dans `application.properties` :

```properties
server.port=8081
```

Puis accéder à : http://localhost:8081/books

### Maven ne trouve pas JAVA_HOME

**Erreur :** `JAVA_HOME is not set`

**Solution Windows :**

```bash
# PowerShell
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-17.x.x-hotspot"
```

### L'application ne démarre pas

**Solution :**

```bash
# Nettoyer et reconstruire
mvn clean
mvn install -DskipTests
mvn spring-boot:run
```

---

## 📞 Besoin d'Aide ?

Si après avoir installé Java et Maven, ça ne fonctionne toujours pas :

1. **Vérifier les versions :**
   ```bash
   java -version
   mvn -version
   ```

2. **Regarder les logs d'erreur** et chercher le message d'erreur

3. **Utiliser IntelliJ IDEA** (c'est la méthode la plus simple !)

---

## 🎓 Recommandation Finale

**Pour ce TP, la méthode la plus simple est d'utiliser IntelliJ IDEA Community Edition (gratuit).**

Il gère tout automatiquement :
- Téléchargement de Java
- Configuration de Maven
- Lancement de l'application

✅ **Télécharger ici :** https://www.jetbrains.com/idea/download/

**Temps total : 10-15 minutes d'installation, puis l'application démarre en 1 clic !**
