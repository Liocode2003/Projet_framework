# Application de Gestion des Livres

## Description

Application web complète de gestion de livres développée avec **Spring Boot**, utilisant **Spring Data JPA** pour la persistance, **Thymeleaf** pour l'interface web et une **API REST** documentée avec **Swagger UI**.

Cette application permet de gérer un catalogue de livres avec les opérations CRUD (Create, Read, Update, Delete) complètes, accessible via une interface web conviviale et une API REST.

---

## Table des matières

1. [Fonctionnalités](#fonctionnalités)
2. [Architecture](#architecture)
3. [Technologies utilisées](#technologies-utilisées)
4. [Prérequis](#prérequis)
5. [Installation et exécution](#installation-et-exécution)
6. [Structure du projet](#structure-du-projet)
7. [API REST](#api-rest)
8. [Interface Web](#interface-web)
9. [Base de données](#base-de-données)
10. [Tests](#tests)
11. [Auteur](#auteur)

---

## Fonctionnalités

### Interface Web (Thymeleaf)
- ✅ Affichage de la liste complète des livres
- ✅ Ajout d'un nouveau livre via formulaire
- ✅ Modification des informations d'un livre existant
- ✅ Suppression d'un livre avec confirmation
- ✅ Recherche de livres par titre ou auteur
- ✅ Visualisation détaillée d'un livre
- ✅ Messages de succès/erreur
- ✅ Interface responsive (Bootstrap 5)

### API REST
- ✅ `GET /api/books` - Récupérer tous les livres
- ✅ `GET /api/books/{id}` - Récupérer un livre par ID
- ✅ `POST /api/books` - Créer un nouveau livre
- ✅ `PUT /api/books/{id}` - Mettre à jour un livre
- ✅ `DELETE /api/books/{id}` - Supprimer un livre
- ✅ `GET /api/books/search/title?q=...` - Rechercher par titre
- ✅ `GET /api/books/search/author?q=...` - Rechercher par auteur
- ✅ `GET /api/books/count` - Compter les livres
- ✅ Documentation interactive avec Swagger UI
- ✅ Validation des données avec Bean Validation
- ✅ Gestion appropriée des codes HTTP

### Persistance
- ✅ Entités JPA avec génération automatique des ID
- ✅ Spring Data JPA pour les opérations CRUD
- ✅ Base de données H2 en mémoire
- ✅ Console H2 accessible pour inspection
- ✅ Initialisation automatique avec données de test

---

## Architecture

L'application suit une **architecture en couches** (layered architecture) conforme aux bonnes pratiques :

```
┌─────────────────────────────────────────────────────────┐
│              COUCHE PRÉSENTATION                        │
│  ┌──────────────────┐    ┌──────────────────────┐      │
│  │  BookController  │    │ BookRestController   │      │
│  │   (MVC/Web)      │    │     (API REST)       │      │
│  └──────────────────┘    └──────────────────────┘      │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              COUCHE MÉTIER                              │
│              ┌──────────────────┐                       │
│              │   BookService    │                       │
│              │  (Logique métier)│                       │
│              └──────────────────┘                       │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              COUCHE PERSISTANCE                         │
│              ┌──────────────────┐                       │
│              │  BookRepository  │                       │
│              │  (Spring Data)   │                       │
│              └──────────────────┘                       │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              BASE DE DONNÉES                            │
│                   H2 Database                           │
└─────────────────────────────────────────────────────────┘
```

### Séparation des responsabilités

#### 1. **Couche Présentation**
- **BookController** : Gère les requêtes HTTP pour l'interface web Thymeleaf
- **BookRestController** : Expose l'API REST JSON
- Responsabilités : Validation des entrées, transformation des données, gestion des réponses HTTP

#### 2. **Couche Métier**
- **BookService** : Contient la logique métier de l'application
- Responsabilités : Orchestration des opérations, règles métier, transactions

#### 3. **Couche Persistance**
- **BookRepository** : Interface Spring Data JPA
- Responsabilités : Accès aux données, requêtes personnalisées
- **Book** : Entité JPA représentant un livre

### Flux de données

**Exemple - Création d'un livre via l'interface web :**
```
1. Utilisateur → Formulaire web
2. BookController.createBook() → Validation
3. BookService.createBook() → Logique métier
4. BookRepository.save() → Persistance
5. Base de données H2
6. Retour → Message de succès → Redirection
```

**Exemple - Récupération via API REST :**
```
1. Client REST → GET /api/books
2. BookRestController.getAllBooks()
3. BookService.getAllBooks()
4. BookRepository.findAll()
5. Base de données H2
6. Retour → JSON Response
```

---

## Technologies utilisées

| Technologie | Version | Usage |
|------------|---------|-------|
| **Java** | 17+ | Langage de programmation |
| **Spring Boot** | 3.2.1 | Framework principal |
| **Spring Data JPA** | 3.2.1 | Couche de persistance |
| **Spring Web** | 3.2.1 | API REST et MVC |
| **Thymeleaf** | 3.2.1 | Moteur de templates |
| **H2 Database** | 2.2.x | Base de données en mémoire |
| **Hibernate** | 6.4.x | ORM (via Spring Data) |
| **SpringDoc OpenAPI** | 2.3.0 | Documentation API (Swagger) |
| **Lombok** | 1.18.30 | Réduction du boilerplate |
| **Maven** | 3.8+ | Gestion des dépendances |
| **Bootstrap** | 5.3.0 | Framework CSS |
| **Font Awesome** | 6.4.0 | Icônes |

---

## Prérequis

- **Java JDK 17** ou supérieur
- **Maven 3.8+**
- Un IDE (IntelliJ IDEA, Eclipse, VS Code, etc.)
- Un navigateur web moderne

---

## Installation et exécution

### 1. Cloner le projet

```bash
git clone <URL_DU_REPOSITORY>
cd book-management-app
```

### 2. Compiler le projet

```bash
mvn clean install
```

### 3. Lancer l'application

```bash
mvn spring-boot:run
```

Ou exécuter directement la classe principale :
```bash
java -jar target/book-management-app-1.0.0.jar
```

### 4. Accéder à l'application

Une fois l'application démarrée, vous pouvez accéder aux différentes interfaces :

| Interface | URL | Description |
|-----------|-----|-------------|
| **Interface Web** | http://localhost:8080/books | Interface utilisateur Thymeleaf |
| **API REST** | http://localhost:8080/api/books | Endpoints REST JSON |
| **Swagger UI** | http://localhost:8080/swagger-ui.html | Documentation interactive API |
| **Console H2** | http://localhost:8080/h2-console | Console de la base de données |

#### Configuration Console H2 :
- **JDBC URL** : `jdbc:h2:mem:bookdb`
- **Username** : `sa`
- **Password** : *(laisser vide)*

---

## Structure du projet

```
book-management-app/
├── src/
│   ├── main/
│   │   ├── java/com/bookmanager/
│   │   │   ├── BookManagementApplication.java   # Classe principale
│   │   │   ├── config/
│   │   │   │   └── OpenApiConfig.java           # Configuration Swagger
│   │   │   ├── controller/
│   │   │   │   ├── BookController.java          # Contrôleur MVC (Thymeleaf)
│   │   │   │   └── BookRestController.java      # Contrôleur REST
│   │   │   ├── entity/
│   │   │   │   └── Book.java                    # Entité JPA
│   │   │   ├── repository/
│   │   │   │   └── BookRepository.java          # Repository Spring Data
│   │   │   └── service/
│   │   │       └── BookService.java             # Service métier
│   │   └── resources/
│   │       ├── application.properties           # Configuration application
│   │       ├── static/
│   │       │   └── css/
│   │       │       └── style.css                # Styles personnalisés
│   │       └── templates/
│   │           ├── layout.html                  # Template de base
│   │           └── books/
│   │               ├── list.html                # Liste des livres
│   │               ├── form.html                # Formulaire création/édition
│   │               └── view.html                # Détails d'un livre
│   └── test/
│       └── java/com/bookmanager/
├── pom.xml                                      # Configuration Maven
└── README.md                                    # Ce fichier
```

---

## API REST

### Endpoints disponibles

#### 1. Récupérer tous les livres
```http
GET /api/books
```
**Réponse :** `200 OK`
```json
[
  {
    "id": 1,
    "title": "Le Petit Prince",
    "author": "Antoine de Saint-Exupéry",
    "price": 12.50
  }
]
```

#### 2. Récupérer un livre par ID
```http
GET /api/books/{id}
```
**Réponse :** `200 OK` ou `404 Not Found`

#### 3. Créer un nouveau livre
```http
POST /api/books
Content-Type: application/json

{
  "title": "Nouveau Livre",
  "author": "Auteur",
  "price": 15.00
}
```
**Réponse :** `201 Created`

#### 4. Mettre à jour un livre
```http
PUT /api/books/{id}
Content-Type: application/json

{
  "title": "Titre Modifié",
  "author": "Auteur Modifié",
  "price": 20.00
}
```
**Réponse :** `200 OK` ou `404 Not Found`

#### 5. Supprimer un livre
```http
DELETE /api/books/{id}
```
**Réponse :** `204 No Content` ou `404 Not Found`

#### 6. Rechercher par titre
```http
GET /api/books/search/title?q=prince
```

#### 7. Rechercher par auteur
```http
GET /api/books/search/author?q=hugo
```

#### 8. Compter les livres
```http
GET /api/books/count
```
**Réponse :** `200 OK`
```json
10
```

### Tester l'API

#### Avec Swagger UI
Accédez à http://localhost:8080/swagger-ui.html pour une documentation interactive et testez directement les endpoints.

#### Avec cURL
```bash
# Récupérer tous les livres
curl http://localhost:8080/api/books

# Créer un livre
curl -X POST http://localhost:8080/api/books \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","author":"Auteur Test","price":10.00}'

# Mettre à jour un livre
curl -X PUT http://localhost:8080/api/books/1 \
  -H "Content-Type: application/json" \
  -d '{"title":"Titre Modifié","author":"Auteur","price":15.00}'

# Supprimer un livre
curl -X DELETE http://localhost:8080/api/books/1
```

---

## Interface Web

### Pages disponibles

#### 1. Liste des livres (`/books`)
- Affiche tous les livres dans un tableau
- Barre de recherche par titre ou auteur
- Actions : Voir, Modifier, Supprimer
- Bouton "Ajouter un Livre"

#### 2. Formulaire (`/books/new` et `/books/edit/{id}`)
- Formulaire de création/modification
- Validation côté client et serveur
- Champs : Titre, Auteur, Prix
- Messages d'erreur en cas de validation échouée

#### 3. Détails (`/books/view/{id}`)
- Affichage complet des informations d'un livre
- Actions : Modifier, Supprimer, Retour à la liste

### Fonctionnalités de l'interface

- **Messages Flash** : Confirmation des actions (création, modification, suppression)
- **Validation** : Tous les champs sont obligatoires, le prix doit être positif
- **Recherche** : Recherche en temps réel par titre ou auteur
- **Design Responsive** : Compatible mobile, tablette, desktop
- **Navigation intuitive** : Menu de navigation accessible partout

---

## Base de données

### Modèle de données

#### Entité Book

| Champ | Type | Contraintes | Description |
|-------|------|-------------|-------------|
| `id` | Long | PK, Auto-increment | Identifiant unique |
| `title` | String | NOT NULL | Titre du livre |
| `author` | String | NOT NULL | Auteur du livre |
| `price` | Double | NOT NULL, > 0 | Prix en euros |

### Configuration H2

L'application utilise une base de données **H2 en mémoire** :
- Les données sont perdues au redémarrage
- Console accessible : http://localhost:8080/h2-console
- Configuration dans `application.properties`

### Données de test

Au démarrage, l'application initialise automatiquement 10 livres de test :
- Le Petit Prince
- 1984
- L'Étranger
- Harry Potter à l'école des sorciers
- Le Seigneur des Anneaux
- Les Misérables
- Germinal
- Le Comte de Monte-Cristo
- Voyage au centre de la Terre
- L'Alchimiste

---

## Tests

### Tests manuels

#### Interface Web
1. Accéder à http://localhost:8080/books
2. Vérifier la liste des livres
3. Créer un nouveau livre via le formulaire
4. Modifier un livre existant
5. Supprimer un livre (avec confirmation)
6. Tester la recherche par titre et auteur

#### API REST via Swagger
1. Accéder à http://localhost:8080/swagger-ui.html
2. Tester chaque endpoint :
   - GET /api/books
   - POST /api/books
   - GET /api/books/{id}
   - PUT /api/books/{id}
   - DELETE /api/books/{id}
3. Vérifier les codes de retour HTTP
4. Tester les cas d'erreur (ID inexistant, données invalides)

### Tests automatisés (optionnel)

Pour étendre le projet, vous pouvez ajouter :
- **Tests unitaires** avec JUnit 5 et Mockito
- **Tests d'intégration** avec `@SpringBootTest`
- **Tests de contrôleurs** avec `MockMvc`
- **Tests de repository** avec `@DataJpaTest`

---

## Choix techniques et justifications

### Pourquoi Spring Boot ?
- **Productivité** : Configuration automatique, démarrage rapide
- **Écosystème** : Intégration native avec Spring Data, Thymeleaf, etc.
- **Production-ready** : Monitoring, métriques, health checks intégrés

### Pourquoi Spring Data JPA ?
- **Abstraction** : Pas besoin d'écrire de SQL
- **Productivité** : Méthodes CRUD automatiques
- **Requêtes dérivées** : `findByTitleContaining()` générées automatiquement

### Pourquoi Thymeleaf ?
- **Natural templates** : Les templates sont du HTML valide
- **Intégration Spring** : Support natif de Spring MVC
- **Extensibilité** : Dialectes, expressions, layouts

### Pourquoi H2 ?
- **Simplicité** : Pas de serveur externe à installer
- **Rapidité** : Base en mémoire, idéale pour le développement
- **Console** : Interface web pour inspecter les données

### Pourquoi Swagger/OpenAPI ?
- **Documentation automatique** : Génération depuis le code
- **Testabilité** : Interface interactive pour tester l'API
- **Standard** : OpenAPI est le standard de facto

---

## Extensions possibles (bonus)

### Validation avancée
- ✅ Validation Bean Validation (déjà implémentée)
- Validation personnalisée (ISBN, etc.)
- Messages d'erreur internationalisés

### Pagination et tri
- Implémenter `PagingAndSortingRepository`
- Ajouter des paramètres `page`, `size`, `sort` à l'API
- Pagination dans l'interface web

### Gestion des erreurs
- `@ControllerAdvice` pour la gestion centralisée
- Classe `ErrorResponse` personnalisée
- Logging structuré avec Logback

### Sécurité
- Spring Security pour l'authentification
- Rôles utilisateur (ADMIN, USER)
- Protection CSRF
- Authentification JWT pour l'API

### Autres améliorations
- Upload d'images de couverture
- Système de notation/commentaires
- Export CSV/Excel
- API de statistiques avancées
- Conteneurisation avec Docker
- Déploiement sur le cloud (Heroku, AWS, etc.)

---

## Auteur

**Projet développé dans le cadre du TP Spring Boot**
- Formation : Développement Web avec Spring Boot
- Année : 2026
- Technologies : Spring Boot, JPA, Thymeleaf, REST API

---

## Licence

Ce projet est sous licence MIT - voir le fichier LICENSE pour plus de détails.

---

## Aide et support

Pour toute question ou problème :
1. Consulter la documentation Swagger : http://localhost:8080/swagger-ui.html
2. Vérifier les logs de l'application
3. Consulter la console H2 pour inspecter les données

**Bon développement !** 🚀
