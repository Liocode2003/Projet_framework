# Guide de Contribution

Merci de votre intérêt pour contribuer à ce projet !

## Structure du code

### Conventions de nommage

- **Classes** : PascalCase (ex: `BookController`, `BookService`)
- **Méthodes** : camelCase (ex: `getAllBooks()`, `findBooksByTitle()`)
- **Variables** : camelCase (ex: `bookRepository`, `totalBooks`)
- **Constantes** : UPPER_SNAKE_CASE (ex: `MAX_PRICE`, `DEFAULT_PAGE_SIZE`)

### Organisation des packages

```
com.bookmanager
├── BookManagementApplication.java  (classe principale)
├── config/                         (configurations)
├── controller/                     (contrôleurs MVC et REST)
├── entity/                         (entités JPA)
├── repository/                     (repositories Spring Data)
└── service/                        (services métier)
```

## Bonnes pratiques

### 1. Annotations Spring

- Utiliser `@RequiredArgsConstructor` (Lombok) pour l'injection de dépendances
- Privilégier l'injection par constructeur plutôt que par champ
- Utiliser `@Transactional` sur les méthodes de service appropriées

### 2. Gestion des erreurs

- Retourner `Optional<T>` pour les méthodes pouvant ne pas trouver de résultat
- Utiliser `ResponseEntity<T>` pour les contrôleurs REST
- Logger les erreurs importantes avec SLF4J

### 3. Validation

- Ajouter les annotations de validation sur les entités
- Utiliser `@Valid` dans les contrôleurs
- Gérer les erreurs de validation avec `BindingResult`

### 4. Documentation

- Ajouter des commentaires JavaDoc pour les méthodes publiques
- Utiliser les annotations Swagger pour documenter l'API REST
- Tenir à jour le README.md en cas de changements majeurs

### 5. Tests

- Écrire des tests unitaires pour la couche service
- Tester les endpoints REST
- Vérifier la validation des données

## Workflow de développement

### 1. Créer une branche

```bash
git checkout -b feature/nom-de-la-fonctionnalite
```

### 2. Développer

- Suivre les conventions de code
- Tester localement
- Documenter les changements

### 3. Commiter

```bash
git add .
git commit -m "feat: description de la fonctionnalité"
```

Types de commits :
- `feat`: Nouvelle fonctionnalité
- `fix`: Correction de bug
- `docs`: Documentation
- `style`: Formatage, indentation
- `refactor`: Refactorisation
- `test`: Ajout de tests
- `chore`: Tâches de maintenance

### 4. Pousser

```bash
git push origin feature/nom-de-la-fonctionnalite
```

### 5. Créer une Pull Request

- Décrire les changements
- Référencer les issues liées
- Attendre la revue de code

## Ajout de nouvelles fonctionnalités

### Exemple : Ajouter un champ "ISBN" aux livres

#### 1. Modifier l'entité

```java
@Entity
public class Book {
    // ... champs existants

    @Column(unique = true)
    private String isbn;
}
```

#### 2. Mettre à jour le service (si nécessaire)

```java
public Optional<Book> findByIsbn(String isbn) {
    return bookRepository.findByIsbn(isbn);
}
```

#### 3. Ajouter la méthode au repository

```java
public interface BookRepository extends JpaRepository<Book, Long> {
    Optional<Book> findByIsbn(String isbn);
}
```

#### 4. Mettre à jour les contrôleurs

```java
@GetMapping("/search/isbn")
public ResponseEntity<Book> searchByIsbn(@RequestParam String isbn) {
    return bookService.findByIsbn(isbn)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
}
```

#### 5. Modifier les templates Thymeleaf

```html
<div class="form-group">
    <label for="isbn">ISBN</label>
    <input type="text" th:field="*{isbn}" class="form-control">
</div>
```

#### 6. Tester

- Interface web : créer/modifier un livre avec ISBN
- API REST : tester via Swagger UI
- Console H2 : vérifier la colonne ISBN

#### 7. Documenter

- Mettre à jour README.md
- Mettre à jour API_DOCUMENTATION.md

## Extensions proposées

Voici des idées de contributions :

### Fonctionnalités de base
- [ ] Ajout du champ ISBN
- [ ] Ajout de la date de publication
- [ ] Catégories de livres
- [ ] Éditeur du livre

### Fonctionnalités avancées
- [ ] Upload d'image de couverture
- [ ] Système de notation (1-5 étoiles)
- [ ] Commentaires sur les livres
- [ ] Stock/quantité disponible
- [ ] Emprunt de livres

### Améliorations techniques
- [ ] Pagination des résultats
- [ ] Tri des colonnes
- [ ] Export CSV/PDF
- [ ] Import depuis fichier
- [ ] Authentification utilisateur
- [ ] API de statistiques
- [ ] Internationalisation (i18n)

### Tests
- [ ] Tests unitaires du service
- [ ] Tests d'intégration
- [ ] Tests des contrôleurs REST
- [ ] Couverture de code >80%

### DevOps
- [ ] Dockerfile
- [ ] Docker Compose
- [ ] CI/CD avec GitHub Actions
- [ ] Déploiement Heroku/AWS

## Questions ?

Si vous avez des questions, n'hésitez pas à :
- Ouvrir une issue sur GitHub
- Consulter la documentation (README.md, ARCHITECTURE.md)
- Regarder les exemples existants dans le code

**Merci de contribuer !** 🙏
