# Guide de Démarrage Rapide

## Lancement en 3 étapes

### 1️⃣ Vérifier les prérequis

```bash
# Vérifier Java (version 17+)
java -version

# Vérifier Maven (version 3.8+)
mvn -version
```

### 2️⃣ Compiler et lancer l'application

```bash
# Compiler le projet
mvn clean install

# Lancer l'application
mvn spring-boot:run
```

### 3️⃣ Accéder aux interfaces

Une fois l'application démarrée (vous verrez "Application de Gestion des Livres démarrée !"), ouvrez votre navigateur :

| Interface | URL | Utilisation |
|-----------|-----|-------------|
| **Interface Web** | http://localhost:8080/books | Gestion visuelle des livres |
| **Swagger UI** | http://localhost:8080/swagger-ui.html | Tester l'API REST |
| **Console H2** | http://localhost:8080/h2-console | Voir la base de données |

---

## Premier test rapide

### Test de l'interface web

1. Ouvrir http://localhost:8080/books
2. Voir la liste des 10 livres pré-chargés
3. Cliquer sur "Ajouter un Livre"
4. Remplir le formulaire et valider
5. Vérifier que le livre apparaît dans la liste

### Test de l'API REST

1. Ouvrir http://localhost:8080/swagger-ui.html
2. Trouver `GET /api/books`
3. Cliquer sur "Try it out" puis "Execute"
4. Vérifier la réponse JSON avec la liste des livres

---

## Connexion Console H2

Pour inspecter la base de données :

1. Aller sur http://localhost:8080/h2-console
2. Remplir les informations :
   - **JDBC URL** : `jdbc:h2:mem:bookdb`
   - **User Name** : `sa`
   - **Password** : *(laisser vide)*
3. Cliquer sur "Connect"
4. Exécuter des requêtes SQL :
   ```sql
   SELECT * FROM books;
   ```

---

## Résolution des problèmes courants

### Erreur : "Port 8080 already in use"
```bash
# Changer le port dans src/main/resources/application.properties
server.port=8081
```

### Erreur : "Java version not compatible"
```bash
# Vérifier que Java 17+ est installé
java -version

# Si nécessaire, installer Java 17 ou supérieur
```

### L'application ne démarre pas
```bash
# Nettoyer le projet et recompiler
mvn clean install -DskipTests

# Relancer
mvn spring-boot:run
```

---

## Arrêter l'application

Appuyer sur `Ctrl+C` dans le terminal où l'application s'exécute.

---

## Prêt à développer ?

Consultez le **README.md** pour la documentation complète, l'architecture et les fonctionnalités avancées.

**Bon développement !** 🚀
