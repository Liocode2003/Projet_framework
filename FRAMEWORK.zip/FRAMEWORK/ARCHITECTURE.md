# Architecture de l'Application

## Vue d'ensemble

L'application **Book Management** suit une architecture **multi-couches** (layered architecture) classique, séparant les responsabilités en couches distinctes avec des interfaces bien définies.

```
┌─────────────────────────────────────────────────────────────────┐
│                     CLIENTS / UTILISATEURS                      │
│                                                                 │
│  ┌──────────────────┐              ┌──────────────────────┐   │
│  │  Navigateur Web  │              │  Client REST         │   │
│  │  (HTML/CSS/JS)   │              │  (Postman, cURL)     │   │
│  └──────────────────┘              └──────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                     COUCHE PRÉSENTATION                         │
│                                                                 │
│  ┌──────────────────────────┐    ┌──────────────────────────┐ │
│  │   BookController         │    │  BookRestController      │ │
│  │   (@Controller)          │    │  (@RestController)       │ │
│  │                          │    │                          │ │
│  │   - Gestion vues         │    │  - Endpoints REST        │ │
│  │   - Validation formulaires│    │  - Réponses JSON        │ │
│  │   - Modèle Thymeleaf     │    │  - Codes HTTP           │ │
│  │   - Redirection          │    │  - Validation Bean      │ │
│  └──────────────────────────┘    └──────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      COUCHE MÉTIER                              │
│                                                                 │
│              ┌────────────────────────────┐                     │
│              │      BookService           │                     │
│              │      (@Service)            │                     │
│              │                            │                     │
│              │  - Logique applicative     │                     │
│              │  - Orchestration           │                     │
│              │  - Transactions (@Transactional)                │
│              │  - Règles métier           │                     │
│              │  - Logging                 │                     │
│              └────────────────────────────┘                     │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    COUCHE PERSISTANCE                           │
│                                                                 │
│              ┌────────────────────────────┐                     │
│              │    BookRepository          │                     │
│              │    (@Repository)           │                     │
│              │    extends JpaRepository   │                     │
│              │                            │                     │
│              │  - CRUD automatique        │                     │
│              │  - Requêtes dérivées       │                     │
│              │  - Requêtes personnalisées │                     │
│              └────────────────────────────┘                     │
│                                                                 │
│              ┌────────────────────────────┐                     │
│              │        Book                │                     │
│              │        (@Entity)           │                     │
│              │                            │                     │
│              │  - Mapping JPA             │                     │
│              │  - Validation              │                     │
│              │  - Relations               │                     │
│              └────────────────────────────┘                     │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                   BASE DE DONNÉES                               │
│                                                                 │
│                  ┌──────────────────┐                           │
│                  │   H2 Database    │                           │
│                  │   (In-Memory)    │                           │
│                  │                  │                           │
│                  │  Table: books    │                           │
│                  └──────────────────┘                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## Couches de l'application

### 1. Couche Présentation

#### BookController (MVC)
**Rôle** : Contrôleur pour l'interface web Thymeleaf

**Responsabilités** :
- Recevoir les requêtes HTTP des utilisateurs (GET, POST)
- Valider les données du formulaire
- Préparer le modèle pour les vues Thymeleaf
- Gérer les redirections et messages flash
- Retourner les noms des templates

**Endpoints** :
- `GET /books` - Liste des livres
- `GET /books/new` - Formulaire création
- `POST /books` - Créer un livre
- `GET /books/edit/{id}` - Formulaire édition
- `POST /books/update/{id}` - Mettre à jour
- `GET /books/view/{id}` - Détails
- `GET /books/delete/{id}` - Supprimer
- `GET /books/search` - Rechercher

**Technologies** :
- Spring MVC
- Thymeleaf
- Bean Validation
- RedirectAttributes pour messages flash

#### BookRestController (API REST)
**Rôle** : Contrôleur pour l'API REST JSON

**Responsabilités** :
- Exposer les endpoints REST
- Retourner des réponses JSON
- Gérer les codes de statut HTTP appropriés
- Valider les données avec Bean Validation
- Documentation Swagger/OpenAPI

**Endpoints REST** :
- `GET /api/books` - Liste JSON
- `GET /api/books/{id}` - Récupérer par ID
- `POST /api/books` - Créer (JSON)
- `PUT /api/books/{id}` - Mettre à jour (JSON)
- `DELETE /api/books/{id}` - Supprimer
- `GET /api/books/search/title?q=...` - Recherche titre
- `GET /api/books/search/author?q=...` - Recherche auteur
- `GET /api/books/count` - Compter

**Technologies** :
- Spring REST
- Jackson (sérialisation JSON)
- Swagger/OpenAPI annotations
- ResponseEntity

---

### 2. Couche Métier

#### BookService
**Rôle** : Service applicatif contenant la logique métier

**Responsabilités** :
- Orchestrer les opérations sur les livres
- Appliquer les règles métier
- Gérer les transactions avec `@Transactional`
- Logger les opérations importantes
- Valider la cohérence des données
- Fournir une API unifiée aux contrôleurs

**Méthodes principales** :
```java
- List<Book> getAllBooks()
- Optional<Book> getBookById(Long id)
- Book createBook(Book book)
- Optional<Book> updateBook(Long id, Book bookDetails)
- boolean deleteBook(Long id)
- List<Book> findBooksByTitle(String title)
- List<Book> findBooksByAuthor(String author)
- long countBooks()
```

**Caractéristiques** :
- Annotation `@Service` pour la détection automatique
- `@Transactional` pour la gestion des transactions
- Injection du repository via constructeur
- Logging avec SLF4J

---

### 3. Couche Persistance

#### BookRepository
**Rôle** : Interface d'accès aux données

**Responsabilités** :
- Fournir les opérations CRUD de base (héritage JpaRepository)
- Définir des requêtes personnalisées
- Abstraction de la couche base de données

**Méthodes** :
```java
// Héritées de JpaRepository
- save(Book book)
- findById(Long id)
- findAll()
- deleteById(Long id)
- count()
- existsById(Long id)

// Requêtes personnalisées
- findByTitleContainingIgnoreCase(String title)
- findByAuthorContainingIgnoreCase(String author)
- findByPriceLessThanEqual(Double price)
```

**Technologies** :
- Spring Data JPA
- Requêtes dérivées (query methods)
- Pas de code SQL manuel

#### Book (Entité)
**Rôle** : Modèle de données persistant

**Attributs** :
- `id` : Identifiant unique (auto-généré)
- `title` : Titre du livre
- `author` : Auteur du livre
- `price` : Prix en euros

**Annotations JPA** :
- `@Entity` : Marque la classe comme entité JPA
- `@Table(name = "books")` : Nom de la table
- `@Id` : Clé primaire
- `@GeneratedValue(strategy = IDENTITY)` : Auto-incrémentation
- `@Column(nullable = false)` : Contraintes de colonne

**Annotations Validation** :
- `@NotBlank` : Champ obligatoire non vide
- `@NotNull` : Valeur non nulle
- `@Positive` : Nombre positif

**Annotations Lombok** :
- `@Data` : getters, setters, equals, hashCode, toString
- `@NoArgsConstructor` : Constructeur sans arguments
- `@AllArgsConstructor` : Constructeur avec tous les arguments
- `@Builder` : Pattern Builder

---

### 4. Configuration

#### OpenApiConfig
**Rôle** : Configuration de la documentation Swagger/OpenAPI

**Responsabilités** :
- Configurer les métadonnées de l'API
- Définir les informations de contact
- Configurer les serveurs
- Personnaliser Swagger UI

#### application.properties
**Rôle** : Configuration de l'application

**Éléments configurés** :
- Port serveur (8080)
- Configuration H2 (URL, credentials)
- Configuration JPA (DDL, SQL logging)
- Console H2
- Thymeleaf (cache, préfixes)
- Swagger/OpenAPI (paths)
- Logging

---

## Flux de données

### Exemple : Création d'un livre via l'interface web

```
1. Utilisateur remplit le formulaire → POST /books

2. BookController.createBook(@Valid Book book, BindingResult)
   ├─ Validation automatique des annotations (@NotBlank, @Positive)
   ├─ Si erreurs → retour au formulaire avec messages
   └─ Si OK → délégation au service

3. BookService.createBook(book)
   ├─ Logging de l'opération
   ├─ Application de règles métier
   └─ Appel du repository

4. BookRepository.save(book)
   ├─ Hibernate génère SQL INSERT
   └─ Insertion dans H2

5. Retour du livre avec ID généré

6. BookController
   ├─ Message flash de succès
   └─ Redirection vers /books

7. Affichage de la liste mise à jour
```

### Exemple : Récupération via API REST

```
1. Client REST → GET /api/books/1

2. BookRestController.getBookById(1L)
   └─ Délégation au service

3. BookService.getBookById(1L)
   ├─ @Transactional(readOnly = true)
   └─ Appel du repository

4. BookRepository.findById(1L)
   ├─ Hibernate génère SQL SELECT
   └─ Récupération depuis H2

5. Optional<Book> retourné

6. BookRestController
   ├─ Si présent → ResponseEntity.ok(book) → 200 OK
   └─ Si absent → ResponseEntity.notFound() → 404

7. Sérialisation JSON par Jackson

8. Réponse HTTP avec JSON au client
```

---

## Principes architecturaux appliqués

### 1. Séparation des préoccupations (Separation of Concerns)
- Chaque couche a une responsabilité unique et bien définie
- Les contrôleurs ne contiennent pas de logique métier
- Les services ne gèrent pas les détails HTTP
- Les repositories ne contiennent que l'accès aux données

### 2. Inversion de contrôle (IoC) et Injection de dépendances (DI)
- Spring gère le cycle de vie des beans
- Injection par constructeur (recommandé)
- Couplage faible entre les couches

### 3. Convention over Configuration
- Spring Boot configure automatiquement JPA, Thymeleaf, etc.
- Pas de XML, configuration par annotations
- Valeurs par défaut sensibles

### 4. DRY (Don't Repeat Yourself)
- Logique métier centralisée dans le service
- Templates Thymeleaf avec layout partagé
- Réutilisation du service par les deux contrôleurs

### 5. Single Responsibility Principle (SRP)
- Chaque classe a une seule raison de changer
- BookController : gestion des vues
- BookRestController : gestion de l'API
- BookService : logique métier
- BookRepository : accès aux données

### 6. Open/Closed Principle
- Les interfaces (BookRepository) sont ouvertes à l'extension
- Le code est fermé à la modification
- Nouvelles requêtes sans modifier le code existant

---

## Technologies transversales

### Validation
- **Bean Validation (JSR-303)** : Validation déclarative avec annotations
- Validation automatique dans les contrôleurs avec `@Valid`
- Messages d'erreur personnalisables

### Gestion des transactions
- **@Transactional** : Gestion déclarative des transactions
- Propagation et isolation configurables
- Rollback automatique en cas d'exception

### Logging
- **SLF4J + Logback** : Logging unifié
- Logs dans la console et fichiers
- Niveaux de log configurables (DEBUG, INFO, WARN, ERROR)

### Mapping Objet-Relationnel
- **Hibernate** : ORM sous-jacent de Spring Data JPA
- Mapping automatique entre objets Java et tables SQL
- Génération automatique du schéma

### Sérialisation JSON
- **Jackson** : Conversion objet ↔ JSON
- Configuration automatique par Spring Boot
- Support des types Java 8 (LocalDate, Optional, etc.)

---

## Points d'extension futurs

### Sécurité
- Ajouter Spring Security
- Authentification JWT pour l'API
- Autorisation basée sur les rôles

### Pagination
- Utiliser `PagingAndSortingRepository`
- Ajouter `Pageable` aux endpoints
- Pagination dans Thymeleaf

### Cache
- Ajouter Spring Cache (`@Cacheable`)
- Redis ou Caffeine comme provider
- Cache des recherches fréquentes

### Validation avancée
- Validateurs personnalisés
- Validation de groupes
- Messages internationalisés (i18n)

### Monitoring
- Spring Boot Actuator
- Métriques avec Micrometer
- Health checks

### Tests
- Tests unitaires (Mockito)
- Tests d'intégration (`@SpringBootTest`)
- Tests de contrôleurs (MockMvc)
- Couverture de code (JaCoCo)

---

**Cette architecture garantit la maintenabilité, l'évolutivité et la testabilité de l'application.**
