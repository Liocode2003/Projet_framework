# Documentation de l'API REST

## URL de base
```
http://localhost:8080/api
```

## Authentification
Aucune authentification n'est requise pour cette version de l'API.

---

## Endpoints

### 📚 Books (Livres)

#### 1. Lister tous les livres

**Requête**
```http
GET /api/books
```

**Réponse** (200 OK)
```json
[
  {
    "id": 1,
    "title": "Le Petit Prince",
    "author": "Antoine de Saint-Exupéry",
    "price": 12.50
  },
  {
    "id": 2,
    "title": "1984",
    "author": "George Orwell",
    "price": 15.00
  }
]
```

**Exemple cURL**
```bash
curl -X GET "http://localhost:8080/api/books" -H "accept: application/json"
```

---

#### 2. Récupérer un livre par ID

**Requête**
```http
GET /api/books/{id}
```

**Paramètres**
- `id` (path, required) : ID du livre

**Réponse** (200 OK)
```json
{
  "id": 1,
  "title": "Le Petit Prince",
  "author": "Antoine de Saint-Exupéry",
  "price": 12.50
}
```

**Erreurs possibles**
- `404 Not Found` : Livre non trouvé

**Exemple cURL**
```bash
curl -X GET "http://localhost:8080/api/books/1" -H "accept: application/json"
```

---

#### 3. Créer un nouveau livre

**Requête**
```http
POST /api/books
Content-Type: application/json
```

**Corps de la requête**
```json
{
  "title": "Nouveau Livre",
  "author": "Nom de l'Auteur",
  "price": 19.99
}
```

**Validation**
- `title` : obligatoire, non vide
- `author` : obligatoire, non vide
- `price` : obligatoire, doit être positif

**Réponse** (201 Created)
```json
{
  "id": 11,
  "title": "Nouveau Livre",
  "author": "Nom de l'Auteur",
  "price": 19.99
}
```

**Erreurs possibles**
- `400 Bad Request` : Données de validation invalides

**Exemple cURL**
```bash
curl -X POST "http://localhost:8080/api/books" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Nouveau Livre",
    "author": "Nom de l'\''Auteur",
    "price": 19.99
  }'
```

---

#### 4. Mettre à jour un livre

**Requête**
```http
PUT /api/books/{id}
Content-Type: application/json
```

**Paramètres**
- `id` (path, required) : ID du livre à modifier

**Corps de la requête**
```json
{
  "title": "Titre Modifié",
  "author": "Auteur Modifié",
  "price": 25.00
}
```

**Réponse** (200 OK)
```json
{
  "id": 1,
  "title": "Titre Modifié",
  "author": "Auteur Modifié",
  "price": 25.00
}
```

**Erreurs possibles**
- `404 Not Found` : Livre non trouvé
- `400 Bad Request` : Données de validation invalides

**Exemple cURL**
```bash
curl -X PUT "http://localhost:8080/api/books/1" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Titre Modifié",
    "author": "Auteur Modifié",
    "price": 25.00
  }'
```

---

#### 5. Supprimer un livre

**Requête**
```http
DELETE /api/books/{id}
```

**Paramètres**
- `id` (path, required) : ID du livre à supprimer

**Réponse** (204 No Content)
Pas de corps de réponse

**Erreurs possibles**
- `404 Not Found` : Livre non trouvé

**Exemple cURL**
```bash
curl -X DELETE "http://localhost:8080/api/books/1"
```

---

#### 6. Rechercher des livres par titre

**Requête**
```http
GET /api/books/search/title?q={query}
```

**Paramètres**
- `q` (query, required) : Texte à rechercher dans les titres

**Réponse** (200 OK)
```json
[
  {
    "id": 1,
    "title": "Le Petit Prince",
    "author": "Antoine de Saint-Exupéry",
    "price": 12.50
  }
]
```

**Exemple cURL**
```bash
curl -X GET "http://localhost:8080/api/books/search/title?q=prince" \
  -H "accept: application/json"
```

---

#### 7. Rechercher des livres par auteur

**Requête**
```http
GET /api/books/search/author?q={query}
```

**Paramètres**
- `q` (query, required) : Texte à rechercher dans les auteurs

**Réponse** (200 OK)
```json
[
  {
    "id": 2,
    "title": "1984",
    "author": "George Orwell",
    "price": 15.00
  }
]
```

**Exemple cURL**
```bash
curl -X GET "http://localhost:8080/api/books/search/author?q=orwell" \
  -H "accept: application/json"
```

---

#### 8. Compter le nombre de livres

**Requête**
```http
GET /api/books/count
```

**Réponse** (200 OK)
```json
10
```

**Exemple cURL**
```bash
curl -X GET "http://localhost:8080/api/books/count" -H "accept: application/json"
```

---

## Codes de statut HTTP

| Code | Signification | Utilisation |
|------|---------------|-------------|
| 200 | OK | Requête réussie (GET, PUT) |
| 201 | Created | Ressource créée avec succès (POST) |
| 204 | No Content | Suppression réussie (DELETE) |
| 400 | Bad Request | Données invalides ou validation échouée |
| 404 | Not Found | Ressource non trouvée |
| 500 | Internal Server Error | Erreur serveur |

---

## Format des erreurs

En cas d'erreur de validation (400 Bad Request) :

```json
{
  "timestamp": "2026-01-19T12:00:00.000+00:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "path": "/api/books"
}
```

---

## Tests avec Postman

### Collection Postman

Vous pouvez créer une collection Postman avec les requêtes suivantes :

1. **GET All Books** : `GET http://localhost:8080/api/books`
2. **GET Book by ID** : `GET http://localhost:8080/api/books/1`
3. **POST Create Book** : `POST http://localhost:8080/api/books`
4. **PUT Update Book** : `PUT http://localhost:8080/api/books/1`
5. **DELETE Book** : `DELETE http://localhost:8080/api/books/1`
6. **GET Search by Title** : `GET http://localhost:8080/api/books/search/title?q=prince`
7. **GET Search by Author** : `GET http://localhost:8080/api/books/search/author?q=hugo`
8. **GET Count Books** : `GET http://localhost:8080/api/books/count`

---

## Tests avec JavaScript (Fetch API)

### Récupérer tous les livres
```javascript
fetch('http://localhost:8080/api/books')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));
```

### Créer un livre
```javascript
fetch('http://localhost:8080/api/books', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    title: 'Nouveau Livre',
    author: 'Auteur Test',
    price: 15.99
  })
})
.then(response => response.json())
.then(data => console.log('Success:', data))
.catch(error => console.error('Error:', error));
```

### Mettre à jour un livre
```javascript
fetch('http://localhost:8080/api/books/1', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    title: 'Titre Modifié',
    author: 'Auteur Modifié',
    price: 20.00
  })
})
.then(response => response.json())
.then(data => console.log('Updated:', data))
.catch(error => console.error('Error:', error));
```

### Supprimer un livre
```javascript
fetch('http://localhost:8080/api/books/1', {
  method: 'DELETE'
})
.then(response => {
  if (response.ok) {
    console.log('Book deleted successfully');
  }
})
.catch(error => console.error('Error:', error));
```

---

## Swagger UI

Pour une documentation interactive complète et la possibilité de tester l'API directement depuis le navigateur, accédez à :

**http://localhost:8080/swagger-ui.html**

Swagger UI offre :
- Documentation interactive complète
- Formulaires pour tester chaque endpoint
- Visualisation des schémas de données
- Codes de réponse et exemples
- Pas besoin d'outils externes

---

## Notes supplémentaires

### CORS
L'API ne configure pas de CORS par défaut. Pour permettre les requêtes cross-origin, ajoutez `@CrossOrigin` aux contrôleurs ou configurez CORS globalement.

### Pagination
La pagination n'est pas implémentée dans cette version. Tous les livres sont retournés en une seule requête.

### Rate Limiting
Aucune limitation de débit n'est appliquée dans cette version.

### Versioning
L'API n'utilise pas de versioning pour le moment. Les changements sont rétrocompatibles.

---

**Pour plus d'informations, consultez le README.md ou Swagger UI.**
