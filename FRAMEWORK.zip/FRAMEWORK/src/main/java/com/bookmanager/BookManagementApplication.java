package com.bookmanager;

import com.bookmanager.entity.Book;
import com.bookmanager.repository.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * Classe principale de l'application Spring Boot.
 * Point d'entrée de l'application de gestion des livres.
 */
@SpringBootApplication
@Slf4j
public class BookManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookManagementApplication.class, args);
        log.info("========================================");
        log.info("Application de Gestion des Livres démarrée !");
        log.info("Interface Web : http://localhost:8080/books");
        log.info("API REST : http://localhost:8080/api/books");
        log.info("Swagger UI : http://localhost:8080/swagger-ui.html");
        log.info("Console H2 : http://localhost:8080/h2-console");
        log.info("========================================");
    }

    /**
     * Initialise la base de données avec des données de test au démarrage.
     * Utile pour le développement et les tests.
     */
    @Bean
    public CommandLineRunner initDatabase(BookRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                log.info("Initialisation de la base de données avec des données de test...");

                repository.save(new Book("Le Petit Prince", "Antoine de Saint-Exupéry", 12.50));
                repository.save(new Book("1984", "George Orwell", 15.00));
                repository.save(new Book("L'Étranger", "Albert Camus", 9.90));
                repository.save(new Book("Harry Potter à l'école des sorciers", "J.K. Rowling", 20.00));
                repository.save(new Book("Le Seigneur des Anneaux", "J.R.R. Tolkien", 25.00));
                repository.save(new Book("Les Misérables", "Victor Hugo", 18.50));
                repository.save(new Book("Germinal", "Émile Zola", 14.00));
                repository.save(new Book("Le Comte de Monte-Cristo", "Alexandre Dumas", 22.00));
                repository.save(new Book("Voyage au centre de la Terre", "Jules Verne", 11.50));
                repository.save(new Book("L'Alchimiste", "Paulo Coelho", 16.00));

                log.info("Base de données initialisée avec {} livres.", repository.count());
            } else {
                log.info("Base de données déjà initialisée avec {} livres.", repository.count());
            }
        };
    }
}
