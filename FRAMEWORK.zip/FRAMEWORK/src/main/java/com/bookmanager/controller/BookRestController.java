package com.bookmanager.controller;

import com.bookmanager.entity.Book;
import com.bookmanager.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contr\u00f4leur REST pour la gestion des livres.
 * Expose les endpoints de l'API REST pour les op\u00e9rations CRUD.
 */
@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Gestion des Livres", description = "API REST pour la gestion des livres")
public class BookRestController {

    private final BookService bookService;

    /**
     * R\u00e9cup\u00e8re la liste de tous les livres
     * GET /api/books
     */
    @Operation(summary = "R\u00e9cup\u00e9rer tous les livres", description = "Retourne la liste compl\u00e8te de tous les livres")
    @ApiResponse(responseCode = "200", description = "Liste r\u00e9cup\u00e9r\u00e9e avec succ\u00e8s")
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        log.info("GET /api/books - R\u00e9cup\u00e9ration de tous les livres");
        List<Book> books = bookService.getAllBooks();
        return ResponseEntity.ok(books);
    }

    /**
     * R\u00e9cup\u00e8re un livre par son ID
     * GET /api/books/{id}
     */
    @Operation(summary = "R\u00e9cup\u00e9rer un livre par ID", description = "Retourne un livre sp\u00e9cifique identifi\u00e9 par son ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Livre trouv\u00e9"),
            @ApiResponse(responseCode = "404", description = "Livre non trouv\u00e9")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(
            @Parameter(description = "ID du livre \u00e0 r\u00e9cup\u00e9rer", required = true)
            @PathVariable Long id) {
        log.info("GET /api/books/{} - R\u00e9cup\u00e9ration du livre", id);
        return bookService.getBookById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Cr\u00e9e un nouveau livre
     * POST /api/books
     */
    @Operation(summary = "Cr\u00e9er un nouveau livre", description = "Cr\u00e9e et sauvegarde un nouveau livre dans la base de donn\u00e9es")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Livre cr\u00e9\u00e9 avec succ\u00e8s"),
            @ApiResponse(responseCode = "400", description = "Donn\u00e9es invalides")
    })
    @PostMapping
    public ResponseEntity<Book> createBook(
            @Parameter(description = "Livre \u00e0 cr\u00e9er", required = true)
            @Valid @RequestBody Book book) {
        log.info("POST /api/books - Cr\u00e9ation d'un nouveau livre: {}", book.getTitle());
        Book createdBook = bookService.createBook(book);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdBook);
    }

    /**
     * Met \u00e0 jour un livre existant
     * PUT /api/books/{id}
     */
    @Operation(summary = "Mettre \u00e0 jour un livre", description = "Met \u00e0 jour les informations d'un livre existant")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Livre mis \u00e0 jour avec succ\u00e8s"),
            @ApiResponse(responseCode = "404", description = "Livre non trouv\u00e9"),
            @ApiResponse(responseCode = "400", description = "Donn\u00e9es invalides")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(
            @Parameter(description = "ID du livre \u00e0 mettre \u00e0 jour", required = true)
            @PathVariable Long id,
            @Parameter(description = "Nouvelles donn\u00e9es du livre", required = true)
            @Valid @RequestBody Book bookDetails) {
        log.info("PUT /api/books/{} - Mise \u00e0 jour du livre", id);
        return bookService.updateBook(id, bookDetails)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Supprime un livre
     * DELETE /api/books/{id}
     */
    @Operation(summary = "Supprimer un livre", description = "Supprime un livre de la base de donn\u00e9es")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Livre supprim\u00e9 avec succ\u00e8s"),
            @ApiResponse(responseCode = "404", description = "Livre non trouv\u00e9")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(
            @Parameter(description = "ID du livre \u00e0 supprimer", required = true)
            @PathVariable Long id) {
        log.info("DELETE /api/books/{} - Suppression du livre", id);
        if (bookService.deleteBook(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Recherche des livres par titre
     * GET /api/books/search/title?q=...
     */
    @Operation(summary = "Rechercher par titre", description = "Recherche les livres contenant le texte sp\u00e9cifi\u00e9 dans le titre")
    @ApiResponse(responseCode = "200", description = "R\u00e9sultats de la recherche")
    @GetMapping("/search/title")
    public ResponseEntity<List<Book>> searchByTitle(
            @Parameter(description = "Texte \u00e0 rechercher dans le titre", required = true)
            @RequestParam String q) {
        log.info("GET /api/books/search/title?q={}", q);
        List<Book> books = bookService.findBooksByTitle(q);
        return ResponseEntity.ok(books);
    }

    /**
     * Recherche des livres par auteur
     * GET /api/books/search/author?q=...
     */
    @Operation(summary = "Rechercher par auteur", description = "Recherche les livres contenant le texte sp\u00e9cifi\u00e9 dans l'auteur")
    @ApiResponse(responseCode = "200", description = "R\u00e9sultats de la recherche")
    @GetMapping("/search/author")
    public ResponseEntity<List<Book>> searchByAuthor(
            @Parameter(description = "Texte \u00e0 rechercher dans l'auteur", required = true)
            @RequestParam String q) {
        log.info("GET /api/books/search/author?q={}", q);
        List<Book> books = bookService.findBooksByAuthor(q);
        return ResponseEntity.ok(books);
    }

    /**
     * R\u00e9cup\u00e8re le nombre total de livres
     * GET /api/books/count
     */
    @Operation(summary = "Compter les livres", description = "Retourne le nombre total de livres dans la base de donn\u00e9es")
    @ApiResponse(responseCode = "200", description = "Nombre de livres r\u00e9cup\u00e9r\u00e9")
    @GetMapping("/count")
    public ResponseEntity<Long> countBooks() {
        log.info("GET /api/books/count");
        long count = bookService.countBooks();
        return ResponseEntity.ok(count);
    }
}
