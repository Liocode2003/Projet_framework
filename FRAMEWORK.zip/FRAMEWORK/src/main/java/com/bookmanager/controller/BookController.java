package com.bookmanager.controller;

import com.bookmanager.entity.Book;
import com.bookmanager.service.BookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/**
 * Contr\u00f4leur MVC pour la gestion de l'interface web Thymeleaf.
 * G\u00e8re les vues HTML et les interactions utilisateur.
 */
@Controller
@RequestMapping("/books")
@RequiredArgsConstructor
@Slf4j
public class BookController {

    private final BookService bookService;

    /**
     * Page d'accueil - Liste de tous les livres
     * GET /books ou /
     */
    @GetMapping
    public String listBooks(Model model) {
        log.info("Affichage de la liste des livres");
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        model.addAttribute("totalBooks", books.size());
        return "books/list";
    }

    /**
     * Redirection de la racine vers la liste des livres
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/books";
    }

    /**
     * Affiche le formulaire de cr\u00e9ation d'un nouveau livre
     * GET /books/new
     */
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        log.info("Affichage du formulaire de cr\u00e9ation");
        model.addAttribute("book", new Book());
        model.addAttribute("isEdit", false);
        return "books/form";
    }

    /**
     * Traite la soumission du formulaire de cr\u00e9ation
     * POST /books
     */
    @PostMapping
    public String createBook(@Valid @ModelAttribute("book") Book book,
                             BindingResult result,
                             RedirectAttributes redirectAttributes,
                             Model model) {
        if (result.hasErrors()) {
            log.warn("Erreurs de validation lors de la cr\u00e9ation: {}", result.getAllErrors());
            model.addAttribute("isEdit", false);
            return "books/form";
        }

        try {
            Book savedBook = bookService.createBook(book);
            log.info("Livre cr\u00e9\u00e9 avec succ\u00e8s: {} (ID: {})", savedBook.getTitle(), savedBook.getId());
            redirectAttributes.addFlashAttribute("successMessage",
                    "Le livre \"" + savedBook.getTitle() + "\" a \u00e9t\u00e9 cr\u00e9\u00e9 avec succ\u00e8s.");
            return "redirect:/books";
        } catch (Exception e) {
            log.error("Erreur lors de la cr\u00e9ation du livre", e);
            model.addAttribute("errorMessage", "Erreur lors de la cr\u00e9ation du livre: " + e.getMessage());
            model.addAttribute("isEdit", false);
            return "books/form";
        }
    }

    /**
     * Affiche le formulaire d'\u00e9dition d'un livre
     * GET /books/edit/{id}
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        log.info("Affichage du formulaire d'\u00e9dition pour le livre {}", id);
        return bookService.getBookById(id)
                .map(book -> {
                    model.addAttribute("book", book);
                    model.addAttribute("isEdit", true);
                    return "books/form";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("errorMessage",
                            "Le livre avec l'ID " + id + " n'a pas \u00e9t\u00e9 trouv\u00e9.");
                    return "redirect:/books";
                });
    }

    /**
     * Traite la soumission du formulaire de modification
     * POST /books/update/{id}
     */
    @PostMapping("/update/{id}")
    public String updateBook(@PathVariable Long id,
                             @Valid @ModelAttribute("book") Book book,
                             BindingResult result,
                             RedirectAttributes redirectAttributes,
                             Model model) {
        if (result.hasErrors()) {
            log.warn("Erreurs de validation lors de la mise \u00e0 jour: {}", result.getAllErrors());
            model.addAttribute("isEdit", true);
            return "books/form";
        }

        try {
            return bookService.updateBook(id, book)
                    .map(updatedBook -> {
                        log.info("Livre mis \u00e0 jour avec succ\u00e8s: {} (ID: {})", updatedBook.getTitle(), updatedBook.getId());
                        redirectAttributes.addFlashAttribute("successMessage",
                                "Le livre \"" + updatedBook.getTitle() + "\" a \u00e9t\u00e9 mis \u00e0 jour avec succ\u00e8s.");
                        return "redirect:/books";
                    })
                    .orElseGet(() -> {
                        redirectAttributes.addFlashAttribute("errorMessage",
                                "Le livre avec l'ID " + id + " n'a pas \u00e9t\u00e9 trouv\u00e9.");
                        return "redirect:/books";
                    });
        } catch (Exception e) {
            log.error("Erreur lors de la mise \u00e0 jour du livre", e);
            model.addAttribute("errorMessage", "Erreur lors de la mise \u00e0 jour du livre: " + e.getMessage());
            model.addAttribute("isEdit", true);
            return "books/form";
        }
    }

    /**
     * Affiche les d\u00e9tails d'un livre
     * GET /books/view/{id}
     */
    @GetMapping("/view/{id}")
    public String viewBook(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        log.info("Affichage des d\u00e9tails du livre {}", id);
        return bookService.getBookById(id)
                .map(book -> {
                    model.addAttribute("book", book);
                    return "books/view";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("errorMessage",
                            "Le livre avec l'ID " + id + " n'a pas \u00e9t\u00e9 trouv\u00e9.");
                    return "redirect:/books";
                });
    }

    /**
     * Supprime un livre
     * GET /books/delete/{id}
     */
    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        log.info("Suppression du livre {}", id);
        if (bookService.deleteBook(id)) {
            redirectAttributes.addFlashAttribute("successMessage",
                    "Le livre a \u00e9t\u00e9 supprim\u00e9 avec succ\u00e8s.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Le livre avec l'ID " + id + " n'a pas \u00e9t\u00e9 trouv\u00e9.");
        }
        return "redirect:/books";
    }

    /**
     * Recherche de livres
     * GET /books/search?query=...&type=...
     */
    @GetMapping("/search")
    public String searchBooks(@RequestParam(required = false) String query,
                              @RequestParam(defaultValue = "title") String type,
                              Model model) {
        log.info("Recherche de livres: query={}, type={}", query, type);

        List<Book> books;
        if (query == null || query.trim().isEmpty()) {
            books = bookService.getAllBooks();
        } else {
            books = switch (type) {
                case "author" -> bookService.findBooksByAuthor(query);
                default -> bookService.findBooksByTitle(query);
            };
        }

        model.addAttribute("books", books);
        model.addAttribute("totalBooks", books.size());
        model.addAttribute("searchQuery", query);
        model.addAttribute("searchType", type);
        return "books/list";
    }
}
