package com.bookmanager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Contrôleur pour la page d'accueil de l'application.
 * Redirige automatiquement vers la liste des livres.
 */
@Controller
public class HomeController {

    /**
     * Redirection de la racine vers la liste des livres
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/books";
    }
}
