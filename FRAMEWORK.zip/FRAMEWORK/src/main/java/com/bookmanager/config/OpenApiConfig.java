package com.bookmanager.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Configuration de la documentation OpenAPI (Swagger).
 * Configure les métadonnées de l'API et l'interface Swagger UI.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Gestion des Livres")
                        .version("1.0.0")
                        .description("""
                                API REST pour la gestion d'une bibliothèque de livres.

                                Cette API permet de :
                                - Créer, lire, mettre à jour et supprimer des livres (CRUD)
                                - Rechercher des livres par titre ou auteur
                                - Consulter les statistiques de la bibliothèque

                                Développée avec Spring Boot, Spring Data JPA et Thymeleaf.
                                """)
                        .contact(new Contact()
                                .name("Équipe de Développement")
                                .email("contact@bookmanager.com")
                                .url("https://github.com/votre-username/book-management-app"))
                        .license(new License()
                                .name("MIT License")
                                .url("https://opensource.org/licenses/MIT")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:8080")
                                .description("Serveur de développement local")
                ));
    }
}
