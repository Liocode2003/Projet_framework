package com.bookmanager.service;

import com.bookmanager.entity.Book;
import com.bookmanager.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service m\u00e9tier pour la gestion des livres.
 * Contient la logique applicative et orchestre les op\u00e9rations CRUD.
 */
@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class BookService {

    private final BookRepository bookRepository;

    /**
     * R\u00e9cup\u00e8re tous les livres
     * @return la liste de tous les livres
     */
    @Transactional(readOnly = true)
    public List<Book> getAllBooks() {
        log.info("R\u00e9cup\u00e9ration de tous les livres");
        return bookRepository.findAll();
    }

    /**
     * R\u00e9cup\u00e8re un livre par son identifiant
     * @param id l'identifiant du livre
     * @return le livre trouv\u00e9, ou Optional.empty() si non trouv\u00e9
     */
    @Transactional(readOnly = true)
    public Optional<Book> getBookById(Long id) {
        log.info("R\u00e9cup\u00e9ration du livre avec l'id: {}", id);
        return bookRepository.findById(id);
    }

    /**
     * Cr\u00e9e un nouveau livre
     * @param book le livre \u00e0 cr\u00e9er
     * @return le livre cr\u00e9\u00e9 avec son identifiant g\u00e9n\u00e9r\u00e9
     */
    public Book createBook(Book book) {
        log.info("Cr\u00e9ation d'un nouveau livre: {}", book.getTitle());
        book.setId(null); // S'assurer que l'ID est null pour une cr\u00e9ation
        return bookRepository.save(book);
    }

    /**
     * Met \u00e0 jour un livre existant
     * @param id l'identifiant du livre \u00e0 mettre \u00e0 jour
     * @param bookDetails les nouvelles donn\u00e9es du livre
     * @return le livre mis \u00e0 jour, ou Optional.empty() si non trouv\u00e9
     */
    public Optional<Book> updateBook(Long id, Book bookDetails) {
        log.info("Mise \u00e0 jour du livre avec l'id: {}", id);
        return bookRepository.findById(id)
                .map(existingBook -> {
                    existingBook.setTitle(bookDetails.getTitle());
                    existingBook.setAuthor(bookDetails.getAuthor());
                    existingBook.setPrice(bookDetails.getPrice());
                    return bookRepository.save(existingBook);
                });
    }

    /**
     * Supprime un livre par son identifiant
     * @param id l'identifiant du livre \u00e0 supprimer
     * @return true si le livre a \u00e9t\u00e9 supprim\u00e9, false si non trouv\u00e9
     */
    public boolean deleteBook(Long id) {
        log.info("Suppression du livre avec l'id: {}", id);
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return true;
        }
        return false;
    }

    /**
     * Recherche les livres par titre
     * @param title le titre \u00e0 rechercher
     * @return la liste des livres correspondants
     */
    @Transactional(readOnly = true)
    public List<Book> findBooksByTitle(String title) {
        log.info("Recherche de livres par titre: {}", title);
        return bookRepository.findByTitleContainingIgnoreCase(title);
    }

    /**
     * Recherche les livres par auteur
     * @param author l'auteur \u00e0 rechercher
     * @return la liste des livres correspondants
     */
    @Transactional(readOnly = true)
    public List<Book> findBooksByAuthor(String author) {
        log.info("Recherche de livres par auteur: {}", author);
        return bookRepository.findByAuthorContainingIgnoreCase(author);
    }

    /**
     * Compte le nombre total de livres
     * @return le nombre de livres
     */
    @Transactional(readOnly = true)
    public long countBooks() {
        return bookRepository.count();
    }
}
