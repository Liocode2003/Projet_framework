package com.bookmanager.repository;

import com.bookmanager.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository pour la gestion de la persistance des entit\u00e9s Book.
 * H\u00e9rite de JpaRepository qui fournit les op\u00e9rations CRUD de base.
 */
@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    /**
     * Recherche les livres par titre (recherche partielle, insensible \u00e0 la casse)
     * @param title le titre \u00e0 rechercher
     * @return la liste des livres correspondants
     */
    List<Book> findByTitleContainingIgnoreCase(String title);

    /**
     * Recherche les livres par auteur (recherche partielle, insensible \u00e0 la casse)
     * @param author l'auteur \u00e0 rechercher
     * @return la liste des livres correspondants
     */
    List<Book> findByAuthorContainingIgnoreCase(String author);

    /**
     * Recherche les livres dont le prix est inf\u00e9rieur ou \u00e9gal \u00e0 une valeur donn\u00e9e
     * @param price le prix maximum
     * @return la liste des livres correspondants
     */
    List<Book> findByPriceLessThanEqual(Double price);
}
