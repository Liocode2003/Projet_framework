package com.bookmanager.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

/**
 * Entit\u00e9 repr\u00e9sentant un livre dans le syst\u00e8me de gestion.
 * Annot\u00e9e avec JPA pour la persistance en base de donn\u00e9es.
 */
@Entity
@Table(name = "books")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Le titre est obligatoire")
    @Column(nullable = false)
    private String title;

    @NotBlank(message = "L'auteur est obligatoire")
    @Column(nullable = false)
    private String author;

    @NotNull(message = "Le prix est obligatoire")
    @Positive(message = "Le prix doit \u00eatre positif")
    @Column(nullable = false)
    private Double price;

    /**
     * Constructeur sans l'identifiant (utile pour la cr\u00e9ation)
     */
    public Book(String title, String author, Double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }
}
