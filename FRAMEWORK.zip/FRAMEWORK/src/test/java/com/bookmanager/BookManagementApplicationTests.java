package com.bookmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Classe de test de base pour vérifier que le contexte Spring Boot se charge correctement.
 */
@SpringBootTest
class BookManagementApplicationTests {

    @Test
    void contextLoads() {
        // Ce test vérifie simplement que l'application Spring Boot démarre correctement
        // et que tous les beans peuvent être créés sans erreur
    }

}
