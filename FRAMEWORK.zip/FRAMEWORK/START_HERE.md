# 🚀 COMMENT DÉMARRER L'APPLICATION

## ⚠️ PROBLÈME : "java: command not found"

Vous avez ce message car **Java et Maven ne sont pas installés** sur votre ordinateur.

---

## ✅ SOLUTION RAPIDE (LA PLUS SIMPLE)

### 📥 **Télécharger IntelliJ IDEA Community (GRATUIT)**

**C'est la méthode la plus simple. IntelliJ s'occupe de tout !**

#### 1️⃣ Télécharger IntelliJ IDEA

🔗 **Lien direct :** https://www.jetbrains.com/idea/download/

- Choisir **"Community Edition"** (gratuit)
- Télécharger pour Windows
- **Temps : 2 minutes**

#### 2️⃣ Installer IntelliJ

- Double-cliquer sur le fichier téléchargé
- Suivre l'installation (options par défaut OK)
- **Temps : 3 minutes**

#### 3️⃣ Ouvrir le projet

1. Lancer IntelliJ IDEA
2. Cliquer sur **"Open"**
3. Naviguer vers : `C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee`
4. Sélectionner le dossier et cliquer **"OK"**
5. ⏳ **Attendre 5-10 minutes** (IntelliJ télécharge Java et Maven automatiquement)

#### 4️⃣ Lancer l'application

1. Dans IntelliJ, ouvrir le fichier :
   ```
   src/main/java/com/bookmanager/BookManagementApplication.java
   ```

2. Chercher cette ligne :
   ```java
   public static void main(String[] args) {
   ```

3. Vous verrez une **flèche verte ▶️** à gauche de cette ligne

4. **Cliquer sur ▶️** puis **"Run 'BookManagementApplication'"**

#### 5️⃣ Accéder à l'application

✅ **Quand vous voyez dans la console :**
```
Application de Gestion des Livres démarrée !
```

🌐 **Ouvrir votre navigateur** et aller sur :

```
http://localhost:8080/books
```

🎉 **L'application fonctionne !**

---

## 🔄 Alternative : Installation Manuelle de Java et Maven

### Si vous ne voulez pas utiliser IntelliJ

#### 1️⃣ Installer Java 17

🔗 **Télécharger ici :** https://adoptium.net/

1. Cliquer sur **"Temurin 17 (LTS)"**
2. Télécharger le **.msi** pour Windows
3. Installer (⚠️ **Cocher "Set JAVA_HOME"** pendant l'installation)
4. **Temps : 5 minutes**

#### 2️⃣ Installer Maven

🔗 **Télécharger ici :** https://maven.apache.org/download.cgi

1. Télécharger **"Binary zip archive"** (apache-maven-X.X.X-bin.zip)
2. Extraire dans `C:\Program Files\Apache\Maven`
3. **Ajouter au PATH :**
   - Rechercher "Variables d'environnement" dans Windows
   - Modifier la variable **"Path"**
   - Ajouter : `C:\Program Files\Apache\Maven\bin`
4. **Temps : 5 minutes**

#### 3️⃣ Vérifier l'installation

**Fermer TOUS les terminaux**, puis ouvrir un **NOUVEAU** terminal :

```bash
java -version
mvn -version
```

✅ Si vous voyez les versions, c'est bon !

#### 4️⃣ Lancer l'application

```bash
cd C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee
mvn spring-boot:run
```

⏳ **Attendre 2-3 minutes** (première fois : téléchargement des dépendances)

#### 5️⃣ Accéder à l'application

🌐 Ouvrir : http://localhost:8080/books

---

## 🎯 RÉCAPITULATIF : Quelle méthode choisir ?

| Méthode | Difficulté | Temps | Recommandé pour |
|---------|-----------|-------|-----------------|
| **IntelliJ IDEA** | ⭐ Facile | 15 min | **Tout le monde** |
| Installation manuelle | ⭐⭐ Moyen | 20 min | Si vous voulez comprendre |
| VS Code | ⭐⭐ Moyen | 20 min | Si vous utilisez déjà VS Code |
| Eclipse | ⭐⭐ Moyen | 20 min | Si vous utilisez déjà Eclipse |

### 🏆 **Méthode recommandée : IntelliJ IDEA**

**Pourquoi ?**
- ✅ Installation automatique de Java et Maven
- ✅ Configuration automatique
- ✅ Lancement en 1 clic
- ✅ Gratuit
- ✅ Le plus utilisé professionnellement

---

## 📱 Une fois l'application lancée

Vous aurez accès à :

| Interface | URL | Description |
|-----------|-----|-------------|
| 🌐 **Interface Web** | http://localhost:8080/books | Gérer les livres visuellement |
| 📡 **Swagger UI** | http://localhost:8080/swagger-ui.html | Tester l'API REST |
| 💾 **Console H2** | http://localhost:8080/h2-console | Voir la base de données |

### Connexion Console H2 :
- **JDBC URL** : `jdbc:h2:mem:bookdb`
- **Username** : `sa`
- **Password** : *(laisser vide)*

---

## ❓ Questions Fréquentes

### Q1 : "Port 8080 already in use" ?

**Solution :** Modifier le port dans `src/main/resources/application.properties`

```properties
server.port=8081
```

Puis accéder à http://localhost:8081/books

### Q2 : L'application ne démarre pas ?

**Vérifier :**
1. Java installé : `java -version` (doit afficher version 17+)
2. Maven installé : `mvn -version` (doit afficher version 3.8+)
3. Dans le bon dossier : `cd C:\Users\lnadz\.claude-worktrees\PDF-Cours\kind-chatterjee`

**Nettoyer et relancer :**
```bash
mvn clean
mvn install
mvn spring-boot:run
```

### Q3 : Ça télécharge pendant longtemps ?

✅ **C'est normal la première fois !**

Maven télécharge toutes les bibliothèques (Spring Boot, Hibernate, etc.)

⏳ **Patience : 2-5 minutes selon votre connexion internet**

### Q4 : Je ne vois rien dans le navigateur ?

**Vérifier :**
1. L'application est bien démarrée (voir la console)
2. Vous allez sur la bonne URL : http://localhost:8080/books
3. Vérifier le port (peut-être 8081 si vous l'avez changé)

---

## 📞 Besoin d'aide supplémentaire ?

Consultez les autres fichiers :

- `INSTALLATION_GUIDE.md` - Guide détaillé d'installation
- `QUICK_START.md` - Guide de démarrage rapide
- `README.md` - Documentation complète
- `ARCHITECTURE.md` - Comprendre le fonctionnement

---

## ✅ Checklist de Démarrage

- [ ] Java 17+ installé (`java -version`)
- [ ] Maven 3.8+ installé (`mvn -version`)
- [ ] Dans le bon dossier (kind-chatterjee)
- [ ] Application lancée (`mvn spring-boot:run` ou via IntelliJ)
- [ ] Message "Application démarrée" visible
- [ ] Navigateur ouvert sur http://localhost:8080/books
- [ ] 10 livres affichés dans la liste

**Si toutes les cases sont cochées : 🎉 Félicitations, ça fonctionne !**

---

## 🎓 POUR LE TP

Une fois l'application qui tourne :

1. ✅ Tester l'interface web (créer, modifier, supprimer des livres)
2. ✅ Tester l'API REST avec Swagger UI
3. ✅ Vérifier la base de données avec la console H2
4. ✅ Créer un repository Git
5. ✅ Pousser le code sur GitHub/Bitbucket
6. ✅ Soumettre le lien avant le **7 février 2026 à 23h59**

---

**🚀 Bon courage ! Avec IntelliJ IDEA, ça devrait marcher en 15 minutes !**
